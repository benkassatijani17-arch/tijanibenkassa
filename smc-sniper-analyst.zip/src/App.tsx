/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Upload, 
  TrendingUp, 
  Activity, 
  BarChart3, 
  Clock, 
  Target, 
  ShieldAlert, 
  ChevronRight,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Zap
} from 'lucide-react';
import { analyzeTradeSetup } from './services/geminiService';
import Markdown from 'react-markdown';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface ImageInput {
  id: number;
  label: string;
  description: string;
  icon: React.ReactNode;
  data: string | null;
  mimeType: string | null;
}

const INITIAL_INPUTS: ImageInput[] = [
  { id: 1, label: '4H Timeframe', description: 'Macro Structure, OBs, FVGs', icon: <Clock className="w-5 h-5" />, data: null, mimeType: null },
  { id: 2, label: '1H Timeframe', description: 'Swing Structure, Inducement', icon: <Clock className="w-5 h-5" />, data: null, mimeType: null },
  { id: 3, label: '3M Timeframe', description: 'Micro Structure, CHoCH', icon: <Clock className="w-5 h-5" />, data: null, mimeType: null },
  { id: 4, label: 'Volume', description: 'Institutional Validation', icon: <BarChart3 className="w-5 h-5" />, data: null, mimeType: null },
  { id: 5, label: 'RSI', description: 'Momentum & Divergence', icon: <Activity className="w-5 h-5" />, data: null, mimeType: null },
];

export default function App() {
  const [inputs, setInputs] = useState<ImageInput[]>(INITIAL_INPUTS);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const handleFileChange = (id: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setInputs(prev => prev.map(input => 
        input.id === id ? { ...input, data: reader.result as string, mimeType: file.type } : input
      ));
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    const missing = inputs.filter(i => !i.data);
    if (missing.length > 0) {
      setError(`Please upload all 5 required images. Missing: ${missing.map(m => m.label).join(', ')}`);
      return;
    }

    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      const imageData = inputs.map(i => ({ data: i.data!, mimeType: i.mimeType! }));
      const analysis = await analyzeTradeSetup(imageData);
      setResult(analysis || "Analysis failed to generate content.");
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during analysis.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const reset = () => {
    setInputs(INITIAL_INPUTS);
    setResult(null);
    setError(null);
  };

  return (
    <div className="min-h-screen trading-grid p-4 md:p-8 font-sans">
      <div className="max-w-6xl mx-auto relative">
        <div className="scanline" />
        
        {/* Header */}
        <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-3 h-3 rounded-full bg-trading-accent animate-pulse" />
              <span className="text-xs font-mono uppercase tracking-[0.2em] text-trading-accent">Institutional Terminal v4.2</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tighter text-white">
              SMC SNIPER <span className="text-trading-accent">ANALYST</span>
            </h1>
            <p className="text-gray-400 mt-2 max-w-xl">
              Algorithmic market analysis engine utilizing Smart Money Concepts and Gemini Vision for zero-drawdown institutional setups.
            </p>
          </div>
          
          <div className="flex gap-4">
            <button 
              onClick={reset}
              className="px-6 py-3 border border-trading-border rounded-lg text-sm font-medium hover:bg-white/5 transition-colors"
            >
              Reset Terminal
            </button>
            <button 
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className={cn(
                "px-8 py-3 bg-trading-accent text-black rounded-lg text-sm font-bold flex items-center gap-2 transition-all active:scale-95",
                isAnalyzing ? "opacity-50 cursor-not-allowed" : "hover:shadow-[0_0_20px_rgba(0,255,157,0.4)]"
              )}
            >
              {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              {isAnalyzing ? "PROCESSING..." : "EXECUTE ANALYSIS"}
            </button>
          </div>
        </header>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Upload Section */}
          <div className="lg:col-span-5 space-y-4">
            <h2 className="text-sm font-mono uppercase tracking-widest text-gray-500 mb-4 flex items-center gap-2">
              <Upload className="w-4 h-4" /> Data Input Channels
            </h2>
            <div className="grid grid-cols-1 gap-3">
              {inputs.map((input, idx) => (
                <motion.div 
                  key={input.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  onClick={() => fileInputRefs.current[idx]?.click()}
                  className={cn(
                    "group relative p-4 rounded-xl border transition-all cursor-pointer overflow-hidden",
                    input.data 
                      ? "bg-trading-accent/5 border-trading-accent/30" 
                      : "bg-trading-card border-trading-border hover:border-trading-accent/50"
                  )}
                >
                  <input 
                    type="file" 
                    accept="image/*"
                    className="hidden"
                    ref={el => fileInputRefs.current[idx] = el}
                    onChange={(e) => handleFileChange(input.id, e)}
                  />
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-10 h-10 rounded-lg flex items-center justify-center transition-colors",
                      input.data ? "bg-trading-accent text-black" : "bg-trading-bg text-gray-500 group-hover:text-trading-accent"
                    )}>
                      {input.data ? <CheckCircle2 className="w-5 h-5" /> : input.icon}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-bold text-white">{input.label}</h3>
                        {input.data && <span className="text-[10px] font-mono text-trading-accent">READY</span>}
                      </div>
                      <p className="text-xs text-gray-500">{input.description}</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-700 group-hover:text-trading-accent transition-colors" />
                  </div>
                  
                  {input.data && (
                    <div className="absolute top-0 right-0 bottom-0 w-16 opacity-10 pointer-events-none">
                      <img src={input.data} alt="preview" className="h-full w-full object-cover grayscale" />
                    </div>
                  )}
                </motion.div>
              ))}
            </div>
          </div>

          {/* Analysis Results */}
          <div className="lg:col-span-7">
            <div className="glass-panel rounded-2xl min-h-[500px] flex flex-col">
              <div className="p-4 border-b border-trading-border flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-trading-accent" />
                  <span className="text-xs font-mono uppercase tracking-widest text-gray-400">Analysis Output</span>
                </div>
                {result && (
                  <div className="flex items-center gap-2 text-[10px] font-mono text-trading-accent">
                    <span className="w-1.5 h-1.5 rounded-full bg-trading-accent animate-pulse" />
                    SIGNAL GENERATED
                  </div>
                )}
              </div>

              <div className="flex-1 p-6 overflow-y-auto max-h-[700px]">
                <AnimatePresence mode="wait">
                  {isAnalyzing ? (
                    <motion.div 
                      key="loading"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="h-full flex flex-col items-center justify-center text-center space-y-4"
                    >
                      <div className="relative">
                        <Loader2 className="w-12 h-12 text-trading-accent animate-spin" />
                        <div className="absolute inset-0 blur-xl bg-trading-accent/20 animate-pulse" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-white">Processing Institutional Data</h3>
                        <p className="text-sm text-gray-500 max-w-xs mx-auto">
                          Gemini Vision is scanning for liquidity pools, order blocks, and fractal confirmations...
                        </p>
                      </div>
                    </motion.div>
                  ) : error ? (
                    <motion.div 
                      key="error"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 rounded-xl bg-trading-danger/10 border border-trading-danger/30 text-trading-danger flex gap-3"
                    >
                      <AlertCircle className="w-5 h-5 shrink-0" />
                      <div>
                        <h4 className="text-sm font-bold">Analysis Error</h4>
                        <p className="text-xs opacity-80">{error}</p>
                      </div>
                    </motion.div>
                  ) : result ? (
                    <motion.div 
                      key="result"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="prose prose-invert prose-sm max-w-none"
                    >
                      <div className="markdown-body">
                        <Markdown>{result}</Markdown>
                      </div>
                    </motion.div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-30">
                      <Target className="w-16 h-16" />
                      <div>
                        <h3 className="text-xl font-bold">Awaiting Market Data</h3>
                        <p className="text-sm max-w-xs mx-auto">
                          Upload all required timeframes and indicators to begin institutional analysis.
                        </p>
                      </div>
                    </div>
                  )}
                </AnimatePresence>
              </div>

              {/* Footer Stats */}
              <div className="p-4 border-t border-trading-border grid grid-cols-3 gap-4">
                <div className="space-y-1">
                  <span className="block text-[10px] font-mono text-gray-500 uppercase">Latency</span>
                  <span className="block text-xs font-bold text-white">~1.2s</span>
                </div>
                <div className="space-y-1">
                  <span className="block text-[10px] font-mono text-gray-500 uppercase">Confidence</span>
                  <span className="block text-xs font-bold text-white">{result ? "High" : "---"}</span>
                </div>
                <div className="space-y-1">
                  <span className="block text-[10px] font-mono text-gray-500 uppercase">Model</span>
                  <span className="block text-xs font-bold text-white">Gemini 3.1 Pro</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Risk Warning */}
        <footer className="mt-12 p-6 rounded-xl border border-trading-danger/20 bg-trading-danger/5 flex items-start gap-4">
          <ShieldAlert className="w-6 h-6 text-trading-danger shrink-0" />
          <div>
            <h4 className="text-sm font-bold text-trading-danger uppercase tracking-wider">Institutional Risk Protocol</h4>
            <p className="text-xs text-gray-500 mt-1 leading-relaxed">
              Trading involves significant risk. This tool is for educational and analytical purposes only. 
              The "Sniper" designation refers to high-probability technical alignment and does not guarantee financial success. 
              Always apply proper risk management and position sizing.
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}
