# tijanibenkassa 🎯

Elite institutional trading analysis tool specializing in Smart Money Concepts (SMC), Wyckoff logic, and Fractal Market Structure. Powered by Gemini 3.1 Pro Vision.

## 🚀 Features

- **Multi-Timeframe Analysis**: Process 4H, 1H, and 3M charts simultaneously.
- **Institutional Logic**: Identifies Order Blocks, FVGs, Liquidity Sweeps, and CHoCH.
- **Sniper Entry Generation**: Precise limit order coordinates with minimal drawdown targets.
- **Professional UI**: Dark-themed, high-fidelity trading terminal interface.

## 📦 Quick Start (Git Commands)

To initialize and push this repository to GitHub:

```bash
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/benkassatijani17-arch/tijanibenkassa.git
git push -u origin main
```

## 🛠️ Tech Stack

- **Frontend**: React 19, Vite, Tailwind CSS 4
- **Animations**: Motion (Framer Motion)
- **Icons**: Lucide React
- **AI Engine**: Google Gemini 3.1 Pro (Vision)

## 📦 Installation

1. **Clone the repository**:
   ```bash
   git clone https://github.com/benkassatijani17-arch/tijanibenkassa.git
   cd tijanibenkassa
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Set up environment variables**:
   Create a `.env` file in the root directory and add your Gemini API Key:
   ```env
   GEMINI_API_KEY=your_api_key_here
   ```

4. **Run the development server**:
   ```bash
   npm run dev
   ```

## 🌐 Deployment

### GitHub Pages

1. Update `vite.config.ts` to include the `base` property:
   ```typescript
   export default defineConfig({
     base: '/tijanibenkassa/',
     // ... rest of config
   })
   ```
2. Build the project:
   ```bash
   npm run build
   ```
3. Deploy the `dist` folder to the `gh-pages` branch.

## ⚠️ Disclaimer

Trading involves significant risk. This tool is for educational and analytical purposes only. It does not constitute financial advice. Always perform your own due diligence and apply strict risk management protocols.

---
Built with ❤️ using Google AI Studio.
